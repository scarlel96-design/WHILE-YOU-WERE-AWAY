# Development continuity

- Keep all agent-launched clients and test programs muted before startup. The user requested silent testing.
- Do not change the user's global volume or normal Minecraft profile. Use isolated development profiles.
- runClient and runClientSmoke apply zero volume to every sound category before launch. Preserve this gate.
- Check audio by decoding files, measuring samples and checking scheduling; do not audibly preview it automatically.
- Distinguish unit, headless Minecraft, client-resource, screenshot and manual-playtest evidence.
- This is a first development slice, not the completed multi-ending campaign. Keep the documented remaining work explicit.
- Historical art slice is 0.3.0-dev.1. Preserve evidence/art/baseline and both prior 0.1/0.2 releases.
- runCitySmoke and runCityReload share a separate muted profile; both need explicit PASS markers, not only process exit 0.
- Vanilla GameTestServer creates only preset dimensions. Actual city creation and persistence are checked in the isolated integrated-client runs.
- CityLayout.VERSION=1 and its stable cell order are persisted construction data. Do not reorder a released plan without migration.
- CityArtLayout.VERSION=2 is used only for new districts. Never replace an existing revision-1 district implicitly.
- City horror is a ledger-gated one-shot client presentation. Keep actor cleanup and the saved one-shot flag covered by the muted smoke/reload tests.
- Package the current art slice with tools/package-art.py --prepare, tools/verify-art-transaction.ps1, then tools/package-art.py. Keep source evidence and runtime evidence distinct.

- The user revised priorities on 2026-09-09. docs/FUNCTION_FIRST.md supersedes previous roadmap ordering. Finish this art pass, then prioritize playable functions, recovery and all-ending integration; defer final art/polish.
- The Overworld remains a core survival/story stage, not merely the city entrance. Never randomly destroy or overwrite player builds.
- Do not call a feature complete without in-game integration, persistence, exception recovery, cleanup and onward progression evidence. For current checkpoint coverage and remaining F01 work, use evidence/stability/GATES.md.

- 0.3.1 introduces schema 4 (reads 1/2/3) and leased scene checkpoints. Check docs/RECOVERY_031.md and evidence/stability/GATES.md before resuming; the complete stability phase is NOT SEALED.
- Preserve evidence/stability/baseline (0.3 JAR/source). Do not overwrite evidence/art or evidence/city with new test output.
- RecoverySmoke is opt-in fault injection. Cut tasks halt only the isolated test JVM after a durable midpoint. A process exit alone never passes: require named gate markers and successful next-process reconstruction.

- User extension 33-81 is recorded in docs/MYSTERY_RESOURCE_EXTENSION.md. Keep stabilization first; resource packs, investigation/puzzles/items and foreshadow runtime follow in the specified order. docs/asset-contract.json tracks current placeholders; no external pack is selected or bundled.
