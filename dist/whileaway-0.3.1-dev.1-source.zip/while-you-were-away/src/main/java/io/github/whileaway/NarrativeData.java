package io.github.whileaway;

import io.github.whileaway.core.*;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Overworld SavedData survives death, logout and dimension travel. Records are player-isolated. */
public final class NarrativeData extends SavedData {
    public static final int SCHEMA = 4;
    private final Map<UUID, Entry> players = new HashMap<>();
    public static final class Entry {
        public Progress progress = Progress.empty();
        public BlockPos station;
        public UUID encounter;
        public long readingUntil;
        public boolean cityVisited;
        public int cityClues;
        public boolean cityShockTriggered;
        public final Map<Integer,SceneRecord> scenes=new TreeMap<>();
        public BlockPos returnPosition;
        public float returnYaw,returnPitch;
        public long transitAfter;
    }
    public Entry entry(UUID id) { return players.computeIfAbsent(id, ignored -> new Entry()); }
    public void discover(UUID id, Clue clue) {
        var e = entry(id); e.progress = e.progress.discover(clue); setDirty();
    }
    public static NarrativeData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(new Factory<>(NarrativeData::new, NarrativeData::load, null), "whileaway_story");
    }
    static NarrativeData load(CompoundTag root, HolderLookup.Provider registry) {
        if (root.getInt("schema") > SCHEMA) throw new IllegalStateException("Story save uses a newer schema; restore the matching mod version.");
        var data = new NarrativeData();
        var list = root.getList("players", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            var t = list.getCompound(i);
            if (!t.hasUUID("id")) continue;
            var e = data.entry(t.getUUID("id"));
            e.progress = new Progress(t.getInt("clues"), t.getLong("next"), t.getInt("events"), t.getBoolean("complete"));
            if (t.contains("station")) e.station = BlockPos.of(t.getLong("station"));
            if (t.hasUUID("encounter")) e.encounter = t.getUUID("encounter");
            e.readingUntil = t.getLong("readingUntil");
            e.cityVisited=t.getBoolean("cityVisited");e.cityClues=t.getInt("cityClues")&7;
            e.cityShockTriggered=t.getBoolean("cityShockTriggered");
            var scenes=t.getList("scenes",Tag.TAG_COMPOUND);
            for(int j=0;j<scenes.size();j++) {
                var scene=SceneRecord.load(scenes.getCompound(j));
                if(e.scenes.putIfAbsent(scene.kind,scene)!=null)throw new IllegalStateException("Duplicate persisted scene kind="+scene.kind);
            }
            // Legacy schema 3 recorded started-as-complete; preserve that fact rather than surprise-replay old worlds.
            if(e.cityShockTriggered&&!e.scenes.containsKey(3)) {
                var legacy=new SceneRecord(3,CityHorror.STAGE);legacy.progress.restore("COMPLETED",4,3,0);e.scenes.put(3,legacy);
            }
            if(root.getInt("schema")<4) {
                if(e.progress.has(Clue.SIGNAL_RESTORED)&&e.station!=null&&!e.scenes.containsKey(1)) {
                    var legacy=new SceneRecord(1,e.station);legacy.progress.restore("COMPLETED",4,127,0);e.scenes.put(1,legacy);
                }
                if(e.cityVisited&&!e.scenes.containsKey(2)) {
                    var legacy=new SceneRecord(2,CityDistrict.ARRIVAL);legacy.progress.restore("COMPLETED",4,127,0);e.scenes.put(2,legacy);
                }
            }
            if(t.contains("returnPosition"))e.returnPosition=BlockPos.of(t.getLong("returnPosition"));
            e.returnYaw=t.getFloat("returnYaw");e.returnPitch=t.getFloat("returnPitch");
            e.transitAfter=Math.max(0,t.getLong("transitAfter"));
        }
        if(root.getInt("schema")<SCHEMA)data.setDirty();
        return data;
    }
    @Override public CompoundTag save(CompoundTag root, HolderLookup.Provider registry) {
        root.putInt("schema", SCHEMA);
        var list = new ListTag();
        players.forEach((id, e) -> {
            var t = new CompoundTag();
            t.putUUID("id", id); t.putInt("clues", e.progress.clues());
            t.putLong("next", e.progress.nextEventTick()); t.putInt("events", e.progress.eventsPlayed());
            t.putBoolean("complete", e.progress.encounterComplete()); t.putLong("readingUntil", e.readingUntil);
            if (e.station != null) t.putLong("station", e.station.asLong());
            if (e.encounter != null) t.putUUID("encounter", e.encounter);
            t.putBoolean("cityVisited",e.cityVisited);t.putInt("cityClues",e.cityClues&7);
            t.putBoolean("cityShockTriggered",e.cityShockTriggered);
            var scenes=new ListTag();e.scenes.values().forEach(r->scenes.add(r.save()));t.put("scenes",scenes);
            if(e.returnPosition!=null)t.putLong("returnPosition",e.returnPosition.asLong());
            t.putFloat("returnYaw",e.returnYaw);t.putFloat("returnPitch",e.returnPitch);t.putLong("transitAfter",e.transitAfter);
            list.add(t);
        });
        root.put("players", list); return root;
    }
}
