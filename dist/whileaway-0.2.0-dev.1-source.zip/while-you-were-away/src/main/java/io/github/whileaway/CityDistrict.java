package io.github.whileaway;

import io.github.whileaway.core.CityLayout;
import net.minecraft.core.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.saveddata.SavedData;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** One shared district per world; bounded batches, persisted cursor, no rebuild on entry. */
public final class CityDistrict extends SavedData {
    public static final ResourceKey<Level> KEY=ResourceKey.create(Registries.DIMENSION,WhileAway.id("quiet_city"));
    public static final BlockPos ARRIVAL=new BlockPos(40,65,68), RETURN_LIGHT=new BlockPos(40,65,72);
    private int cursor;
    private boolean started;
    public boolean ready(){return cursor==CityLayout.CELLS.size();}
    public int cursor(){return cursor;}
    public void start(){if(!started){started=true;setDirty();}}
    public static CityDistrict get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(new Factory<>(CityDistrict::new,CityDistrict::load,null),"whileaway_district_v1");
    }
    public static CityDistrict load(CompoundTag t,HolderLookup.Provider registry) {
        if(t.getInt("version")!=CityLayout.VERSION)throw new IllegalStateException("District layout version mismatch");
        var d=new CityDistrict();d.cursor=t.getInt("cursor");d.started=t.getBoolean("started");
        if(d.cursor<0||d.cursor>CityLayout.CELLS.size())throw new IllegalStateException("District cursor invalid");
        return d;
    }
    @Override public CompoundTag save(CompoundTag t,HolderLookup.Provider registry) {
        t.putInt("version",CityLayout.VERSION);t.putInt("cursor",cursor);t.putBoolean("started",started);return t;
    }
    public int advance(ServerLevel level,int budget) {
        if(!level.dimension().equals(KEY))throw new IllegalArgumentException("District placement requires quiet_city");
        int count=0;
        while(started&&!ready()&&count<Math.min(512,Math.max(0,budget))) {
            var c=CityLayout.CELLS.get(cursor);var pos=new BlockPos(c.x(),CityLayout.BASE_Y+c.y(),c.z());
            level.getChunkAt(pos);
            level.setBlock(pos,state(c.kind()),2);
            cursor++;count++;
        }
        if(count>0)setDirty();return count;
    }
    public static BlockState state(CityLayout.Kind kind) {
        return switch(kind) {
            case ROAD -> Blocks.GRAY_CONCRETE.defaultBlockState();
            case LINE -> Blocks.YELLOW_TERRACOTTA.defaultBlockState();
            case PAVING -> Blocks.POLISHED_ANDESITE.defaultBlockState();
            case WALL -> Blocks.DEEPSLATE_BRICKS.defaultBlockState();
            case TRIM -> Blocks.POLISHED_DEEPSLATE.defaultBlockState();
            case GLASS -> Blocks.GRAY_STAINED_GLASS.defaultBlockState();
            case FLOOR -> Blocks.DARK_OAK_PLANKS.defaultBlockState();
            case LAMP -> Blocks.SEA_LANTERN.defaultBlockState();
            case POST -> Blocks.DEEPSLATE_BRICK_WALL.defaultBlockState();
            case BENCH -> Blocks.DARK_OAK_SLAB.defaultBlockState();
            case GATE -> WhileAway.RETURN_LIGHT.get().defaultBlockState();
            case INTAKE -> WhileAway.CITY_INTAKE.get().defaultBlockState();
            case HOME -> WhileAway.CITY_HOME.get().defaultBlockState();
            case SIREN -> WhileAway.CITY_SIREN.get().defaultBlockState();
        };
    }
    @SubscribeEvent public void tick(ServerTickEvent.Post event) {
        var level=event.getServer().getLevel(KEY);
        if(level!=null){var data=get(level);if(data.started&&!data.ready())data.advance(level,256);}
    }
}
