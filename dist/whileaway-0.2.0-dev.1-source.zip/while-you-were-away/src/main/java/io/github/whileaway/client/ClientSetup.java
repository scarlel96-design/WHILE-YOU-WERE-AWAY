package io.github.whileaway.client;

import io.github.whileaway.WhileAway;
import io.github.whileaway.entity.Wayfarer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

@EventBusSubscriber(modid=WhileAway.ID,bus=EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public final class ClientSetup {
    @SubscribeEvent public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(WhileAway.WAYFARER.get(), Renderer::new);
    }
    public static final class Model extends GeoModel<Wayfarer> {
        @Override public ResourceLocation getModelResource(Wayfarer entity) { return WhileAway.id("geo/wayfarer.geo.json"); }
        @Override public ResourceLocation getTextureResource(Wayfarer entity) {
            // Native game texture reference, not a redistributed Mojang asset. Art pass remains pending.
            return ResourceLocation.withDefaultNamespace("textures/entity/enderman/enderman.png");
        }
        @Override public ResourceLocation getAnimationResource(Wayfarer entity) { return WhileAway.id("animations/wayfarer.animation.json"); }
    }
    public static final class Renderer extends GeoEntityRenderer<Wayfarer> {
        public Renderer(EntityRendererProvider.Context context) { super(context,new Model()); shadowRadius=.55f; }
    }
}
