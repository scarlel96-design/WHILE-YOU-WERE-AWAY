package io.github.whileaway;

import io.github.whileaway.core.*;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.neoforged.neoforge.gametest.*;

/** Headless integration tests; these use real NeoForge registries and Minecraft NBT. */
@GameTestHolder(WhileAway.ID)
@PrefixGameTestTemplate(false)
public final class StoryGameTests {
    @GameTest(template="empty")
    public static void stateRoundTrip(GameTestHelper h) {
        var d=new NarrativeData();var id=UUID.randomUUID();var e=d.entry(id);
        d.discover(id,Clue.STATION);d.discover(id,Clue.WARNING_READ);d.discover(id,Clue.SIGNAL_RESTORED);
        e.station=new BlockPos(-123,64,987);e.encounter=UUID.randomUUID();e.readingUntil=9876;
        e.progress=e.progress.eventPlayed(100,900);
        var loaded=NarrativeData.load(d.save(new CompoundTag(),h.getLevel().registryAccess()),h.getLevel().registryAccess());
        var actual=loaded.entry(id);
        h.assertTrue(actual.progress.equals(e.progress),"progress round-trip");
        h.assertTrue(actual.station.equals(e.station),"negative station coordinate survives");
        h.assertTrue(actual.encounter.equals(e.encounter),"entity ticket survives");
        h.assertTrue(actual.readingUntil==9876,"reading grace survives");h.succeed();
    }
    @GameTest(template="empty")
    public static void playersStayIsolated(GameTestHelper h) {
        var d=new NarrativeData();var a=UUID.randomUUID();var b=UUID.randomUUID();
        d.discover(a,Clue.STATION);d.discover(a,Clue.WARNING_READ);
        h.assertTrue(d.entry(a).progress.stage()==2,"first player progresses");
        h.assertTrue(d.entry(b).progress.stage()==0,"second player stays quiet");h.succeed();
    }
    @GameTest(template="empty")
    public static void futureSchemaRejected(GameTestHelper h) {
        var t=new CompoundTag();t.putInt("schema",NarrativeData.SCHEMA+1);boolean rejected=false;
        try {NarrativeData.load(t,h.getLevel().registryAccess());}catch(IllegalStateException expected){rejected=true;}
        h.assertTrue(rejected,"future data must not be overwritten");h.succeed();
    }
    @GameTest(template="empty")
    public static void stationTemplatePlaces(GameTestHelper h) {
        var optional=h.getLevel().getStructureManager().get(WhileAway.id("abandoned_station"));
        h.assertTrue(optional.isPresent(),"station NBT resolves");var template=optional.orElseThrow();
        h.assertTrue(template.getSize().equals(new BlockPos(19,10,19)),"station dimensions");
        var origin=h.absolutePos(new BlockPos(0,1,0));
        boolean placed=template.placeInWorld(h.getLevel(),origin,origin,new StructurePlaceSettings(),h.getLevel().getRandom(),Block.UPDATE_ALL);
        h.assertTrue(placed,"station placed");
        h.assertTrue(h.getLevel().getBlockState(origin.offset(6,1,9)).is(WhileAway.STATION.get()),"anchor placed");
        h.assertTrue(h.getLevel().getBlockEntity(origin.offset(6,1,9)) instanceof io.github.whileaway.content.StationEntity,"anchor ticker entity");
        h.assertTrue(h.getLevel().getBlockState(origin.offset(8,1,6)).is(WhileAway.RELAY.get()),"relay placed");h.succeed();
    }
    @GameTest(template="empty")
    public static void worldgenRegistriesResolve(GameTestHelper h) {
        var access=h.getLevel().registryAccess();
        h.assertTrue(access.registryOrThrow(Registries.STRUCTURE).containsKey(WhileAway.id("abandoned_station")),"structure registered");
        h.assertTrue(access.registryOrThrow(Registries.STRUCTURE_SET).containsKey(WhileAway.id("stations")),"placement registered");
        h.assertTrue(access.registryOrThrow(Registries.TEMPLATE_POOL).containsKey(WhileAway.id("station")),"pool registered");h.succeed();
    }
    @GameTest(template="empty")
    public static void worldgenBuildsPieces(GameTestHelper h) {
        var level=h.getLevel();var generator=level.getChunkSource().getGenerator();
        var structure=level.registryAccess().registryOrThrow(Registries.STRUCTURE).get(WhileAway.id("abandoned_station"));
        var context=new net.minecraft.world.level.levelgen.structure.Structure.GenerationContext(
            level.registryAccess(),generator,generator.getBiomeSource(),level.getChunkSource().randomState(),
            level.getStructureManager(),74192361L,new net.minecraft.world.level.ChunkPos(0,0),level,b->true);
        var point=((net.minecraft.world.level.levelgen.structure.structures.JigsawStructure)structure).findGenerationPoint(context);
        h.assertTrue(point.isPresent(),"station generation point");
        h.assertTrue(!point.orElseThrow().getPiecesBuilder().build().pieces().isEmpty(),"jigsaw must emit a piece; depth zero emits none in 1.21.1");h.succeed();
    }
    @GameTest(template="empty")
    public static void scenePacketRoundTrip(GameTestHelper h) {
        var buffer=new net.minecraft.network.RegistryFriendlyByteBuf(io.netty.buffer.Unpooled.buffer(),h.getLevel().registryAccess());
        try {
            var input=new ScenePayload(1,new BlockPos(-123,75,987));
            ScenePayload.CODEC.encode(buffer,input);
            h.assertTrue(ScenePayload.CODEC.decode(buffer).equals(input),"scene packet coordinates and kind survive");
        } finally {buffer.release();}
        h.succeed();
    }
    @GameTest(template="empty")
    public static void entitySerializes(GameTestHelper h) {
        var mob=WhileAway.WAYFARER.get().create(h.getLevel());var owner=UUID.randomUUID();
        h.assertTrue(mob!=null,"entity factory");mob.bind(owner,new BlockPos(1,5,7));
        var t=new CompoundTag();mob.saveWithoutId(t);
        var copy=WhileAway.WAYFARER.get().create(h.getLevel());copy.load(t);
        h.assertTrue(owner.equals(copy.witness()),"encounter ownership saved");
        h.assertTrue(copy.getMaxHealth()==28f,"attributes registered");h.succeed();
    }
    @GameTest(template="empty")
    public static void bookComponentsResolve(GameTestHelper h) {
        var book=WhileAway.WARNING_BOOK.get().getDefaultInstance();
        var pages=book.get(net.minecraft.core.component.DataComponents.WRITTEN_BOOK_CONTENT);
        h.assertTrue(pages!=null&&pages.pages().size()==2,"localized book pages");h.succeed();
    }
    @GameTest(template="empty")
    public static void schemaOneMigrates(GameTestHelper h) {
        var id=UUID.randomUUID();var d=new NarrativeData();d.discover(id,Clue.STATION);
        var t=d.save(new CompoundTag(),h.getLevel().registryAccess());t.putInt("schema",1);
        var player=t.getList("players",10).getCompound(0);
        for(var key:java.util.List.of("cityVisited","cityClues","returnPosition","returnYaw","returnPitch","transitAfter"))player.remove(key);
        var e=NarrativeData.load(t,h.getLevel().registryAccess()).entry(id);
        h.assertTrue(e.progress.has(Clue.STATION)&&!e.cityVisited&&e.cityClues==0&&e.returnPosition==null,"schema 1 progress retained, city defaults empty");h.succeed();
    }
    @GameTest(template="empty")
    public static void cityReturnPointRoundTrip(GameTestHelper h) {
        var d=new NarrativeData();var id=UUID.randomUUID();var e=d.entry(id);
        e.returnPosition=new BlockPos(-333,68,-275);e.returnYaw=123.5f;e.returnPitch=-17.5f;
        e.cityVisited=true;e.cityClues=5;e.transitAfter=321;
        var a=NarrativeData.load(d.save(new CompoundTag(),h.getLevel().registryAccess()),h.getLevel().registryAccess()).entry(id);
        h.assertTrue(a.returnPosition.equals(e.returnPosition)&&a.returnYaw==123.5f&&a.returnPitch==-17.5f,"return position/orientation survive reload");
        h.assertTrue(a.cityVisited&&a.cityClues==5&&a.transitAfter==321,"city state persists");h.succeed();
    }
    @GameTest(template="empty")
    public static void cityPlacementRejectsOverworld(GameTestHelper h) {
        // Vanilla GameTestServer bakes an empty dimension registry into the FLAT preset.
        // Actual custom-dimension generation/resume is checked by CitySmoke instead.
        h.assertTrue(h.getLevel().registryAccess().registryOrThrow(Registries.DIMENSION_TYPE).containsKey(WhileAway.id("quiet_city")),"city dimension type decodes");
        h.assertTrue(h.getLevel().registryAccess().registryOrThrow(Registries.BIOME).containsKey(WhileAway.id("quiet_city")),"city biome decodes");
        var d=new CityDistrict();d.start();boolean rejected=false;
        try {d.advance(h.getLevel(),1);}catch(IllegalArgumentException expected){rejected=true;}
        h.assertTrue(rejected&&d.cursor()==0,"district never writes to overworld");h.succeed();
    }
    @GameTest(template="empty")
    public static void invalidCityCursorRejected(GameTestHelper h) {
        var t=new CompoundTag();t.putInt("version",1);t.putInt("cursor",-1);boolean fail=false;
        try{CityDistrict.load(t,h.getLevel().registryAccess());}catch(IllegalStateException expected){fail=true;}
        h.assertTrue(fail,"invalid cursor rejected rather than overwrite district");h.succeed();
    }
    @GameTest(template="empty")
    public static void relayLightAndCityBooks(GameTestHelper h) {
        var relay=WhileAway.RELAY.get().defaultBlockState();
        h.assertTrue(!relay.getValue(io.github.whileaway.content.RelayBlock.LIT),"relay starts unlit");
        var p=h.absolutePos(new BlockPos(3,2,3));h.getLevel().setBlock(p,relay.setValue(io.github.whileaway.content.RelayBlock.LIT,true),3);
        h.assertTrue(h.getLevel().getBlockState(p).getLightEmission(h.getLevel(),p)==12,"lit relay emits light");
        for(var item:java.util.List.of(WhileAway.CITY_INTAKE_BOOK.get(),WhileAway.CITY_HOME_BOOK.get(),WhileAway.CITY_SIREN_BOOK.get()))
            h.assertTrue(item.getDefaultInstance().get(net.minecraft.core.component.DataComponents.WRITTEN_BOOK_CONTENT).pages().size()==2,"city book two pages");h.succeed();
    }
    @GameTest(template="empty")
    public static void blockedLandingRejected(GameTestHelper h) {
        var p=h.absolutePos(new BlockPos(10,4,10));
        for(int y=-4;y<=5;y++)h.getLevel().setBlock(p.offset(0,y,0),net.minecraft.world.level.block.Blocks.STONE.defaultBlockState(),2);
        h.assertTrue(CityTransit.findLanding(h.getLevel(),p,0)==null,"solid shaft never accepted");
        h.getLevel().setBlock(p,net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(),2);
        h.getLevel().setBlock(p.above(),net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(),2);
        h.assertTrue(p.equals(CityTransit.findLanding(h.getLevel(),p,0)),"clear two-block landing accepted");h.succeed();
    }
}
