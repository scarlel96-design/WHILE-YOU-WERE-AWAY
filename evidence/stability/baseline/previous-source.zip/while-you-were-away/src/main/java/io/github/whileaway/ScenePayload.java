package io.github.whileaway;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
public record ScenePayload(int kind,BlockPos origin) implements CustomPacketPayload {
    public static final Type<ScenePayload> TYPE=new Type<>(WhileAway.id("scene"));
    public static final StreamCodec<RegistryFriendlyByteBuf,ScenePayload> CODEC=StreamCodec.composite(
        ByteBufCodecs.VAR_INT,ScenePayload::kind,BlockPos.STREAM_CODEC,ScenePayload::origin,ScenePayload::new);
    @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
}
