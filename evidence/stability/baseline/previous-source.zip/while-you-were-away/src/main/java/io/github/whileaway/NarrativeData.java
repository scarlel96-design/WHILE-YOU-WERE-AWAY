package io.github.whileaway;

import io.github.whileaway.core.*;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Overworld SavedData survives death, logout and dimension travel. Records are player-isolated. */
public final class NarrativeData extends SavedData {
    public static final int SCHEMA = 3;
    private final Map<UUID, Entry> players = new HashMap<>();
    public static final class Entry {
        public Progress progress = Progress.empty();
        public BlockPos station;
        public UUID encounter;
        public long readingUntil;
        public boolean cityVisited;
        public int cityClues;
        public boolean cityShockTriggered;
        public BlockPos returnPosition;
        public float returnYaw,returnPitch;
        public long transitAfter;
    }
    public Entry entry(UUID id) { return players.computeIfAbsent(id, ignored -> new Entry()); }
    public void discover(UUID id, Clue clue) {
        var e = entry(id); e.progress = e.progress.discover(clue); setDirty();
    }
    public static NarrativeData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(new Factory<>(NarrativeData::new, NarrativeData::load, null), "whileaway_story");
    }
    static NarrativeData load(CompoundTag root, HolderLookup.Provider registry) {
        if (root.getInt("schema") > SCHEMA) throw new IllegalStateException("Story save uses a newer schema; restore the matching mod version.");
        var data = new NarrativeData();
        var list = root.getList("players", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            var t = list.getCompound(i);
            if (!t.hasUUID("id")) continue;
            var e = data.entry(t.getUUID("id"));
            e.progress = new Progress(t.getInt("clues"), t.getLong("next"), t.getInt("events"), t.getBoolean("complete"));
            if (t.contains("station")) e.station = BlockPos.of(t.getLong("station"));
            if (t.hasUUID("encounter")) e.encounter = t.getUUID("encounter");
            e.readingUntil = t.getLong("readingUntil");
            e.cityVisited=t.getBoolean("cityVisited");e.cityClues=t.getInt("cityClues")&7;
            e.cityShockTriggered=t.getBoolean("cityShockTriggered");
            if(t.contains("returnPosition"))e.returnPosition=BlockPos.of(t.getLong("returnPosition"));
            e.returnYaw=t.getFloat("returnYaw");e.returnPitch=t.getFloat("returnPitch");
            e.transitAfter=Math.max(0,t.getLong("transitAfter"));
        }
        return data;
    }
    @Override public CompoundTag save(CompoundTag root, HolderLookup.Provider registry) {
        root.putInt("schema", SCHEMA);
        var list = new ListTag();
        players.forEach((id, e) -> {
            var t = new CompoundTag();
            t.putUUID("id", id); t.putInt("clues", e.progress.clues());
            t.putLong("next", e.progress.nextEventTick()); t.putInt("events", e.progress.eventsPlayed());
            t.putBoolean("complete", e.progress.encounterComplete()); t.putLong("readingUntil", e.readingUntil);
            if (e.station != null) t.putLong("station", e.station.asLong());
            if (e.encounter != null) t.putUUID("encounter", e.encounter);
            t.putBoolean("cityVisited",e.cityVisited);t.putInt("cityClues",e.cityClues&7);
            t.putBoolean("cityShockTriggered",e.cityShockTriggered);
            if(e.returnPosition!=null)t.putLong("returnPosition",e.returnPosition.asLong());
            t.putFloat("returnYaw",e.returnYaw);t.putFloat("returnPitch",e.returnPitch);t.putLong("transitAfter",e.transitAfter);
            list.add(t);
        });
        root.put("players", list); return root;
    }
}
