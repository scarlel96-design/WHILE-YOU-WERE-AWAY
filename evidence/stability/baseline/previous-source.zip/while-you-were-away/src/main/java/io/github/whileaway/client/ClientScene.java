package io.github.whileaway.client;

import io.github.whileaway.*;
import io.github.whileaway.core.SceneTimeline;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.*;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.*;

/** Client-only presentation. Never changes camera, keybindings, gamma, or the player's world. */
@EventBusSubscriber(modid=WhileAway.ID,value=Dist.CLIENT)
public final class ClientScene {
    private static int age=-1;
    private static int kind=1;
    private static int loadingGrace;
    private static BlockPos origin=BlockPos.ZERO;
    private static ResourceKey<Level> dimension;
    private static final java.util.List<io.github.whileaway.entity.Wayfarer> figures=new java.util.ArrayList<>();
    private static net.minecraft.client.multiplayer.ClientLevel actorWorld;
    public static int apparitionCount(){return figures.size();}
    public static boolean active(){return age>=0;}
    public static void receive(ScenePayload payload) {
        var mc=Minecraft.getInstance();
        cancel();
        if((payload.kind()<1||payload.kind()>3)||mc.level==null)return;
        kind=payload.kind();
        loadingGrace=kind==2?200:0;
        origin=payload.origin();dimension=mc.level.dimension();age=0;
        mc.getSoundManager().stop(null,SoundSource.MUSIC);
    }
    private static void cancel(){
        if(actorWorld!=null)for(var figure:figures)actorWorld.removeEntity(figure.getId(),net.minecraft.world.entity.Entity.RemovalReason.DISCARDED);
        figures.clear();actorWorld=null;age=-1;dimension=null;
    }
    @SubscribeEvent public static void tick(ClientTickEvent.Post event) {
        if(age<0)return;var mc=Minecraft.getInstance();
        if(loadingGrace>0&&mc.screen instanceof net.minecraft.client.gui.screens.ReceivingLevelScreen){loadingGrace--;return;}
        if(mc.level==null||mc.player==null||!mc.player.isAlive()||mc.level.dimension()!=dimension
                ||mc.screen!=null||mc.isPaused()||mc.player.blockPosition().distSqr(origin)>40*40){cancel();return;}
        age++;
        if(kind==3) {
            if(age==60) {
                actorWorld=mc.level;
                for(int i=0;i<7;i++) {
                    var entity=WhileAway.WAYFARER.get().create(mc.level);
                    int id=-200000-i;if(mc.level.getEntity(id)!=null){cancel();return;}
                    entity.setId(id);entity.setNoAi(true);entity.setNoGravity(true);
                    entity.moveTo(origin.getX()-6+i*2+.5,origin.getY()+3.2,origin.getZ()+.5,0,0);
                    mc.level.addEntity(entity);figures.add(entity);
                }
                play(WhileAway.BREATH.get(),origin,.55f);
            }
            // All seven drop into the lane together, stopping above the ground: the departure never completed.
            if(age>=130&&age<150)for(var figure:figures)figure.setPos(figure.getX(),origin.getY()+3.2-(age-130)*.14,figure.getZ());
            if(age==130)play(WhileAway.ATTACK.get(),origin,.48f);
            if(age==195){for(var figure:figures)actorWorld.removeEntity(figure.getId(),net.minecraft.world.entity.Entity.RemovalReason.DISCARDED);figures.clear();}
        }
        if(age==45)play(WhileAway.KNOCK.get(),origin.offset(8,2,0),.32f);
        if(age==110)play(WhileAway.STEPS.get(),origin.offset(-7,0,5),.3f);
        if(age==150)play(WhileAway.BREATH.get(),origin.offset(0,1,10),.2f);
        if(age>=65&&age<150&&age%5==0) {
            double x=origin.getX()+.5+(age-65)/85.0*5;
            mc.level.addParticle(ParticleTypes.ASH,x,origin.getY()+.2,origin.getZ()+.5,0,.006,0);
        }
        if(age>=SceneTimeline.LENGTH)cancel();
    }
    private static void play(SoundEvent sound,BlockPos at,float volume) {
        var mc=Minecraft.getInstance();
        mc.level.playLocalSound(at.getX()+.5,at.getY()+.5,at.getZ()+.5,sound,SoundSource.AMBIENT,volume,1,false);
    }
    @SubscribeEvent public static void render(RenderGuiEvent.Post event) {
        if(age<0||!ClientConfig.CINEMATIC_OVERLAY.get())return;
        var mc=Minecraft.getInstance();if(mc.screen!=null||mc.player==null)return;
        var frame=SceneTimeline.at(age);var g=event.getGuiGraphics();int w=g.guiWidth(),h=g.guiHeight();
        int alpha=(int)(frame.pressure()*105),dark=(alpha<<24)|0x071015,transparent=0x00071015;
        int edge=Math.max(8,h/5),bar=(int)(h*frame.bars());
        g.fillGradient(0,0,w,edge,dark,transparent);g.fillGradient(0,h-edge,w,h,transparent,dark);
        if(bar>0){g.fill(0,0,w,bar,0xff07090d);g.fill(0,h-bar,w,h,0xff07090d);}
        int captionY=h-(mc.gameMode!=null&&mc.gameMode.canHurtPlayer()?76:38);
        if(frame.caption()!=0)g.drawCenteredString(mc.font,Component.translatable((kind==3?"scene.whileaway.seven.":kind==2?"scene.whileaway.city.":"scene.whileaway.signal.")+frame.caption()),w/2,captionY,0xd9d1bc);
    }
}
