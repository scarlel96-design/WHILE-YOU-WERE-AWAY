"""Package this first development slice only after its observed runtime gates pass."""
from pathlib import Path
import hashlib, json, shutil, zipfile

root = Path(__file__).resolve().parents[1]
log = (root / 'evidence/runtime-final.log').read_text(encoding='utf-8-sig')
smoke = (root / 'evidence/client-smoke.txt').read_text(encoding='utf-8')
assert 'All 9 required tests passed' in log
assert 'WHILEAWAY_SMOKE_PASS' in log and 'WHILEAWAY_SMOKE_FAILED' not in log
assert 'BUILD SUCCESSFUL' in log and 'VERIFIED MUTED before launch' in log
assert 'PASS tracked custom entity present with camera line of sight' in smoke
assert 'master volume remains zero' in smoke
rows = json.loads((root / 'evidence/transaction.json').read_text(encoding='utf-8-sig'))
assert all(row['exit'] == 0 for row in rows)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
baseline = root / 'evidence/baseline/ThreatPolicy.java'
modified = root / 'src/main/java/io/github/whileaway/core/ThreatPolicy.java'
assert sha(baseline) == '8b125547cfb45abb58a8849eeb8749582cdfcd0239f1c689c2705575505506c0'
assert sha(modified) == '1663ed61e6280e99f5ea0a1ac19abf9c02a5502aa9eb9cdbc30dcf775cc2b7b5'
assert sha(root / 'build/rollback-copy/ThreatPolicy.java') == sha(baseline)
dist = root / 'dist'
dist.mkdir(exist_ok=True)
jar = dist / 'whileaway-0.1.0-dev.1.jar'
shutil.copyfile(root / 'build/libs' / jar.name, jar)

report = [
    'WHILE YOU WERE AWAY 0.1.0-dev.1 — FIRST DEVELOPMENT SLICE',
    'Date: 2026-09-09 KST',
    'Full campaign status: NOT COMPLETE. Final art / multiplayer live / full survival playthrough: NOT TESTED.',
    'Changed branch: ThreatPolicy.mayManifest: return false -> distinctClues >= 3 && signalRestored.',
    'Baseline provenance: newly created no-encounter scaffold from this development run, not an earlier shipped mod.',
    'Additional fixes: worldgen jigsaw size 0 -> 1; silent prelaunch options for both dev client tasks;',
    '12-second relay presentation, scene codec, physical generated-station and client line-of-sight tests.',
    'MODIFIED_FILE=' + str(modified),
    'DIFF_FILE=' + str(root / 'evidence/DIFF.patch'),
    'VERIFICATION=' + str(root / 'VERIFICATION.txt'),
    'ROLLBACK=' + str(root / 'ROLLBACK.sh'),
    'BASELINE_SHA256=' + sha(baseline),
    'MODIFIED_SHA256=' + sha(modified),
    'JAR=' + str(jar),
    'JAR_SHA256=' + sha(jar),
    '',
    'BASELINE / MODIFIED / ROLLBACK exact observed commands; working directory=' + str(root),
]
for row in rows:
    report += [row['phase'], 'COMMAND: ' + row['command'], 'INPUT: ' + row['input'],
               'LITERAL OUTPUT: ' + (row['output'] or '(empty)'), 'EXIT STATUS: ' + str(row['exit']), '']
report += [
    'Restored behavior: copy returns mayManifest=false for (3,true); original baseline hash matches.',
    'Final working status: MODIFIED_FILE remains changed, returns mayManifest=true for (3,true).',
    'Rollback scope: policy source only. Does not uninstall the mod, rebuild a JAR, or alter worlds.',
    'ROLLBACK.sh executable verified with Git Bash chmod +x and test -x. Source ZIP preserves executable mode.',
    'Initial sandbox Git Bash attempt failed to create signal pipe (Win32 error 5); rerun outside sandbox passed.',
    '',
    'CURRENT VALIDATION',
    r'COMMAND: .\gradlew.bat build runGameTestServer runClientSmoke --console=plain',
    'INPUT: Java 21, Minecraft 1.21.1, NeoForge 21.1.249, GeckoLib 4.9.2; isolated seed 74192361 world.',
    'LITERAL OUTPUT: All 9 required tests passed :)',
    'LITERAL OUTPUT: WHILEAWAY_SMOKE_PASS',
    'LITERAL OUTPUT: BUILD SUCCESSFUL in 1m 51s' if 'BUILD SUCCESSFUL in 1m 51s' in log else next(line for line in log.splitlines() if line.startswith('BUILD SUCCESSFUL')),
    'EXIT STATUS: 0',
    'Full literal log: ' + str(root / 'evidence/runtime-final.log'),
    r'COMMAND: .\tools\test-core.ps1',
    'INPUT: core policy, ledger, director, scene timeline tables.',
    'LITERAL OUTPUT: PASS core assertions=1571',
    'EXIT STATUS: 0',
    r'COMMAND: python .\tools\verify-assets.py .\build\libs\whileaway-0.1.0-dev.1.jar',
    'INPUT: generated resources plus final built JAR.',
    'LITERAL OUTPUT: PASS asset assertions=6654; station/animation/localization/OGG/JAR',
    'EXIT STATUS: 0',
    r'COMMAND: pwsh -NoProfile -File .\tools\verify-mute.ps1',
    'INPUT: ' + str(root.parent.parent / 'work/client-smoke/options.txt'),
    'LITERAL OUTPUT: PASS muted options: 10 sound categories=0.0; narrator=0; isolated profile',
    'EXIT STATUS: 0',
    r"COMMAND: $env:PYTHONPATH='C:\Users\scarl\Documents\Codex\2026-09-08\new-chat\work\audio-deps'; & 'C:\Users\scarl\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' .\tools\verify-audio.py",
    'INPUT: seven original synthesized OGG files; no playback device opened.',
    'LITERAL OUTPUT: PASS audio files=7; decoded/finite/duration/mono/44100Hz/peak<0.95; playback=NONE',
    'EXIT STATUS: 0',
    '',
    'CLIENT EVIDENCE', smoke,
    'Screenshot review: natural station exterior, visible prototype Wayfarer and Korean scene caption.',
    'Client smoke uses an observation entity and a server-sent presentation packet. It is not a complete survival-quest playthrough.',
    'No forced music playback. Auditory quality/listening evaluation: NOT TESTED.',
    'Warning: one world-generation tick delay was logged; no sustained performance or shader compatibility claim.',
]
(root / 'VERIFICATION.txt').write_text('\n'.join(report) + '\n', encoding='utf-8')
files = []
for folder in ['src', 'tools', 'docs', 'gradle']:
    files += [p for p in (root / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += [root / name for name in ['README.md','AGENTS.md','.gitignore','build.gradle','gradle.properties','settings.gradle','gradlew','gradlew.bat','ROLLBACK.sh','VERIFICATION.txt']]
for name in ['baseline/ThreatPolicy.java','DIFF.patch','transaction.json','audio-assets.json','runtime-final.log','client-smoke.txt']:
    files.append(root / 'evidence' / name)
files += list((root / 'evidence/screenshots').glob('*.png'))
manifest = root / 'evidence/SOURCE_MANIFEST.sha256'
manifest.write_text(''.join(f'{sha(p)}  {p.relative_to(root).as_posix()}\n' for p in sorted(files)), encoding='utf-8')
files.append(manifest)
archive = dist / 'whileaway-0.1.0-dev.1-source.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files):
        name = 'while-you-were-away/' + p.relative_to(root).as_posix()
        info = zipfile.ZipInfo(name, (2026,9,9,0,0,0))
        info.create_system = 3
        info.external_attr = (0o100755 if p.name in ['ROLLBACK.sh','gradlew'] else 0o100644) << 16
        z.writestr(info, p.read_bytes(), compress_type=zipfile.ZIP_DEFLATED)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for p in files:
        assert z.read('while-you-were-away/' + p.relative_to(root).as_posix()) == p.read_bytes()
    assert z.getinfo('while-you-were-away/ROLLBACK.sh').external_attr >> 16 & 0o111
with zipfile.ZipFile(jar) as z:
    assert z.testzip() is None
    assert z.read('io/github/whileaway/WhileAway.class')[:4] == bytes.fromhex('cafebabe')
(dist / 'SHA256SUMS.txt').write_text(f'{sha(jar)}  {jar.name}\n{sha(archive)}  {archive.name}\n', encoding='utf-8')
for p in [modified, root/'evidence/DIFF.patch', root/'VERIFICATION.txt', root/'ROLLBACK.sh', root/'README.md', root/'docs/DIRECTION.md', dist/'SHA256SUMS.txt']:
    assert p.read_text(encoding='utf-8').strip()
print(f'PASS package source files={len(files)}; ZIP byte equality; executable rollback; JAR reopened')
print('JAR SHA256=' + sha(jar))
print('SOURCE SHA256=' + sha(archive))
