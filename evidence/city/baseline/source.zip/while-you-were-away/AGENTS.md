# Development continuity

- Keep all agent-launched clients and test programs muted before startup. The user requested silent testing.
- Do not change the user's global volume or normal Minecraft profile. Use isolated development profiles.
- runClient and runClientSmoke apply zero volume to every sound category before launch. Preserve this gate.
- Check audio by decoding files, measuring samples and checking scheduling; do not audibly preview it automatically.
- Distinguish unit, headless Minecraft, client-resource, screenshot and manual-playtest evidence.
- This is a first development slice, not the completed multi-ending campaign. Keep the documented remaining work explicit.
