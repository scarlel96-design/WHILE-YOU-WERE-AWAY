package io.github.whileaway.client;

import io.github.whileaway.*;
import io.github.whileaway.core.SceneTimeline;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.*;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.*;

/** Client-only presentation. Never changes camera, keybindings, gamma, or the player's world. */
@EventBusSubscriber(modid=WhileAway.ID,value=Dist.CLIENT)
public final class ClientScene {
    private static int age=-1;
    private static BlockPos origin=BlockPos.ZERO;
    private static ResourceKey<Level> dimension;
    public static boolean active(){return age>=0;}
    public static void receive(ScenePayload payload) {
        var mc=Minecraft.getInstance();
        if(payload.kind()!=1||mc.level==null){cancel();return;}
        origin=payload.origin();dimension=mc.level.dimension();age=0;
        mc.getSoundManager().stop(null,SoundSource.MUSIC);
    }
    private static void cancel(){age=-1;dimension=null;}
    @SubscribeEvent public static void tick(ClientTickEvent.Post event) {
        if(age<0)return;var mc=Minecraft.getInstance();
        if(mc.level==null||mc.player==null||!mc.player.isAlive()||mc.level.dimension()!=dimension
                ||mc.screen!=null||mc.isPaused()||mc.player.blockPosition().distSqr(origin)>40*40){cancel();return;}
        age++;
        if(age==45)play(WhileAway.KNOCK.get(),origin.offset(8,2,0),.32f);
        if(age==110)play(WhileAway.STEPS.get(),origin.offset(-7,0,5),.3f);
        if(age==150)play(WhileAway.BREATH.get(),origin.offset(0,1,10),.2f);
        if(age>=65&&age<150&&age%5==0) {
            double x=origin.getX()+.5+(age-65)/85.0*5;
            mc.level.addParticle(ParticleTypes.ASH,x,origin.getY()+.2,origin.getZ()+.5,0,.006,0);
        }
        if(age>=SceneTimeline.LENGTH)cancel();
    }
    private static void play(SoundEvent sound,BlockPos at,float volume) {
        var mc=Minecraft.getInstance();
        mc.level.playLocalSound(at.getX()+.5,at.getY()+.5,at.getZ()+.5,sound,SoundSource.AMBIENT,volume,1,false);
    }
    @SubscribeEvent public static void render(RenderGuiEvent.Post event) {
        if(age<0||!ClientConfig.CINEMATIC_OVERLAY.get())return;
        var mc=Minecraft.getInstance();if(mc.screen!=null||mc.player==null)return;
        var frame=SceneTimeline.at(age);var g=event.getGuiGraphics();int w=g.guiWidth(),h=g.guiHeight();
        int alpha=(int)(frame.pressure()*105),dark=(alpha<<24)|0x071015,transparent=0x00071015;
        int edge=Math.max(8,h/5),bar=(int)(h*frame.bars());
        g.fillGradient(0,0,w,edge,dark,transparent);g.fillGradient(0,h-edge,w,h,transparent,dark);
        if(bar>0){g.fill(0,0,w,bar,0xff07090d);g.fill(0,h-bar,w,h,0xff07090d);}
        if(frame.caption()!=0)g.drawCenteredString(mc.font,Component.translatable("scene.whileaway.signal."+frame.caption()),w/2,h-38,0xd9d1bc);
    }
}
