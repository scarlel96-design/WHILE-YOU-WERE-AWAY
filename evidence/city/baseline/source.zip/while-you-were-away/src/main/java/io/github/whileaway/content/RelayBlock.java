package io.github.whileaway.content;
import io.github.whileaway.*;
import io.github.whileaway.core.*;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public final class RelayBlock extends Block {
    public RelayBlock(Properties p) { super(p); }
    @Override protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (player instanceof ServerPlayer server) {
            var data = NarrativeData.get(server.getServer()); var e = data.entry(player.getUUID());
            if (e.progress.has(Clue.SIGNAL_RESTORED)) player.displayClientMessage(Component.translatable("story.whileaway.already_restored"), true);
            else if (!Director.canRestore(e.progress) || e.station == null || e.station.distSqr(pos) > 32 * 32 || level.dimension() != Level.OVERWORLD)
                player.displayClientMessage(Component.translatable("story.whileaway.read_first"), true);
            else {
                int slot = -1;
                for (int i=0; i<player.getInventory().items.size(); i++) if (player.getInventory().items.get(i).is(Items.REDSTONE)) { slot=i; break; }
                if (slot < 0 && !player.isCreative()) player.displayClientMessage(Component.translatable("story.whileaway.need_redstone"), true);
                else {
                    if (!player.isCreative()) player.getInventory().items.get(slot).shrink(1);
                    data.discover(player.getUUID(), Clue.SIGNAL_RESTORED);
                    e.progress = e.progress.defer(level.getGameTime() + 400);
                    data.setDirty();
                    player.displayClientMessage(Component.translatable("story.whileaway.signal"), false);
                    StoryEvents.sound(server, WhileAway.SIGNAL.get(), SoundSource.BLOCKS, pos, 0.7f);
                    net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(server,new ScenePayload(1,pos));
                }
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
